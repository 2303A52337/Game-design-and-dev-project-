# Rally Pioneers Racing — Neon Horizon edition (Sanjay Karupothula, 2303A52337)

## What is new in this edition
- Third track: **Neon Horizon — Midnight Circuit** (night city, neon kerbs, towers, street lamps, headlight beam).
- New car style: **GT Coupe** (closed wheels, glass cabin, spoiler, glowing lights, underglow). Pick it with the CAR button on the main menu.
- TRACK button now cycles Desert -> Forest -> Neon City.
- Unity compilation could not be run in the authoring environment: open in Unity 2021.3.45f2 and check the Console once.

# Rally Pioneers Racing — Unity 2021.3 LTS

This download is a complete Unity source project, not an executable or a Unity package.
Both nitrogen and boost have been removed: no power buttons, arches, pickups, speed surges or exhaust flames.

## Open the UPDATED project in Unity Hub
1. Download the new ZIP from the preview page. Extract ALL files into a NEW folder; do not overwrite the old Procedural_Update folder.
2. In Unity Hub > Installs, install Unity 2021.3.45f2. If it is not listed, use the official Unity download archive: https://unity.com/releases/editor/whats-new/2021.3.45f2 (Install in Unity Hub).
3. In Hub > Projects > Add > Add project from disk, select the inner RallyPioneersRacing folder. It must directly contain Assets, Packages and ProjectSettings. Do not select the ZIP, Assets alone, or the outer extraction folder.
4. In the project's Editor version column, choose 2021.3.45f2. If no editor version is assigned, install that editor first and select it; a listing in Hub alone does not open the game.
5. Click the newly added project and allow the initial import to complete.
6. Choose Rally Pioneers > Open Game Scene, or open Assets/Scenes/RallyMain.unity.
7. Press Play, click the Game tab, choose a track, then Start Race. The scene looks empty before Play because the track, cars and crowd are generated at runtime.

## If the project will not open
- 'Editor not installed' or an empty Editor version: install and assign 2021.3.45f2 in Hub.
- 'Invalid project': select the inner folder containing Assets, Packages and ProjectSettings after fully extracting.
- Existing old Hub entry: add this new extraction separately; the old entry still points to your old files.
- Package import errors: this edition uses only built-in Unity modules, with unused third-party/render-pipeline packages removed. Close Unity, delete only Library and Temp in this NEW extraction if present, and reopen it. Never delete Assets or ProjectSettings.
- An empty Game view: open RallyMain and press Play; do not rename the scene.
- Keep Built-in rendering and legacy Input Manager (Edit > Project Settings > Player > Active Input Handling: Input Manager or Both). Do not switch to Input System-only.
- Unity 6/2022 and older versions were not tested. This archive targets Unity 2021.3 LTS; changing the version text alone does not convert a project.
- For unresolved errors, send the first red Console error and the installed editor version.

## Driving
W / Up / gas pedal: accelerate. S / Down / brake pedal: brake, then reverse.
A / Left / left button: left. D / Right / right button: right.
Space: handbrake. B: recover to track. R: restart. Esc: pause.
Two distinct circuits, five AI rivals, three laps, safe grass run-off, perimeter fences, animated crowds, speed dial and minimap.

## Build for Windows
Install Windows Build Support for Unity 2021.3.45f2 in Hub, then use Rally Pioneers > Build Windows Game.
Choose an empty output folder and share the ENTIRE resulting folder, not just the EXE.
The editor helper automatically retains the Standard shader used by the generated car and scenery materials.

## Version-only update
This archive targets Unity 2021.3.45f2, revision 88f88f591b2e, verified against Unity's official release page. All game scripts, scene files, track layouts, visual assets, input settings and package dependencies are unchanged from the previous clear-road edition. The editor performs any required import when first opened.

## Checks and limitation
The archive layout, source/configuration and browser driving were checked. Unity is not installed in the authoring environment, so Unity compilation, import and Play mode remain unverified.
